/*$('.c').hide();
$('img').click(function() {
    $('img').toggle() {
        $('.n').hide();
        $('.c').show();
    }
});
/*$('img').click(function() {
    $('c').hide();
    $('n').show();
});*/

/*$('img').click(function() {
    $('img').attr('data-alt-src');
        }*/

/*$(function() {
    $('button').on('click', function() {
        if ($('img').attr('src')) {
            $('img').attr('data-alt-src');
        } else {
            $('img').attr('src');
        }
    });
})*/
$('img').hide('.c');

$(function() {
            $('button').on('click', function() {
                    if ($('img').show('.c'); $('img').hide('.n'));
                    else {
                        $('img').show('.n');
                        $('img').hide('.c');
                    }
                }
            }